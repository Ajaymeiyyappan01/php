<?php
function ajay(){
echo"Iam IT student";
}
ajay();
echo"<br/>";

function add($a,$b){
$c=$a+$b;
echo"result is ".$c;
}
add(20,30);
echo"<br/>";

function sub($a,$b){
$c=$a-$b;
return ($c);
}

echo"result is ".sub(30,40);
?>