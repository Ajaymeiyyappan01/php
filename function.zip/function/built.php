<?php
//string
$str="technologies";
echo strlen($str);
echo"<br/>";
$substring = substr($str, 7, 3);
echo "Substring: " . $substring ;
echo"<br/>";
//array
$fruits = ["Apple", "Banana"];
array_push($fruits, "Cherry", "Date");
print_r($fruits); 
echo"<br/>";
$vegetables = ["carrot", "Broccoli"];
$mergedArray = array_merge($fruits, $vegetables);

echo"<br/>";
$abc="tomato";
array_splice($fruits,2,3,[$abc]);
print_r($mergedArray);
//math
echo rand(1, 10)."\n";
echo abs(-5);
?>