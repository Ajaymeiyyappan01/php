<?php
//indexed
$a=array("one","two","three");
echo $a[2].'<br/>';
for($i=0;$i<3;$i++){
echo $a [$i ];
echo"<br/>";
}

//associative
$b=array("red"=>10,"green"=>20,"black"=>30);
echo $b["green"]."<br/>";
foreach($b as $x=>$value){
echo 'key :' .$x .'value:'.$value.'<br/>';
}

//multi
$c=array(
    array(1,2,3),
    array(4,5,3)
);
echo $c[1][2];
?>