<?php

$x=100;
$y=100;
if($x<$y){
echo "x is greatest";
}
elseif($x>$y){
echo"y is greatest";
}
else{
echo"both are equal";
}
?>