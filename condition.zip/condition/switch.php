<?php

$ajay="4";
switch($ajay){
case "1":
	echo"one";break;
case "2":
	echo"two";break;

case"3":
	echo"three";
default:
	echo"no number";
}
?>

