<?php
$x=2985;
if($x<=500){
echo "no discount";
}
elseif($x>501 && $x<999){
$dis=$x*(5/100);
echo $x-$dis;
}
elseif($x>1000 && $x<1499){
$dis=$x*(10/100);
echo $x-$dis;
}
else{
$dis=$x*(20/100);
echo $x-$dis;
}
?>