<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
if (!empty($username) && !empty($email) && !empty($password)) {
        try {
            $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password' => $password
            ]);
            echo "<script>alert('Registration successful!'); window.location.href = 'login.php';</script>";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { 
                echo "<script>alert('Email already exists!');</script>";
            } else {
                echo "Error: " . $e->getMessage(); 
            }
        }
    } else {
        echo "<script>alert('All fields are required!');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    <form method="POST" action="">
        <label>Username:</label><br>
        <input type="text" name="username" required><br><br>
        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>
        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>
        <button type="submit">Register</button>
    </form>
</body>
</html>
