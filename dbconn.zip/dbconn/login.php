<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    if (!empty($email) && !empty($password)) {
        try {
            $sql = "SELECT * FROM users WHERE email = :email";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            
            if ($user && $password === $user['password']) {
                echo "<script>alert('Login successful!'); window.location.href = 'dashboard.php';</script>";
            } else {
                echo "<script>alert('Invalid email or password!');</script>";
            }
        } catch (PDOException $e) {
            echo "<script>alert('An error occurred. Please try again later.');</script>";
        }
    } else {
        echo "<script>alert('All fields are required!');</script>";
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="">
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
