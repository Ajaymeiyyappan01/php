<?php

//for
for($x=0;$x<10;$x++){
echo $x;
}
echo"<br/>";

for($x=10;$x>0;$x--){
echo $x;

}
echo"<br/>";

//while
$j=10;
while($j<10){
echo $j;
$j++;
}

echo"<br/>";
// //do
// $z=10;
// do{
// echo $z;
// $z++;
// }
// while($z<10) 


//foreach
$arr=array("bike","car");
foreach($arr as $a){
echo "$a"." ";
}

?>