<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "user");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$message = "";

// Handle Login
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $hashedPassword = md5($password); // Hash the entered password to match stored hash

    $query = "SELECT * FROM user WHERE username='$username' AND password='$hashedPassword'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        echo "<script>alert('Login successful!');</script>";
        // Redirect or display user dashboard here
    } else {
        $message = "User not found";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <p style="color:red;"><?php echo $message; ?></p>
    <form method="POST">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username"><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password"><br><br>

        <button type="submit" name="login">Login</button>
    </form>
    <p>Don't have an account? <a href="regi.php">Register here</a></p>
</body>
</html>
