<!DOCTYPE html>
<html>
<head>
    <title>Form Validation</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $errorMessage = "";

    if (empty($name)) {
        $errorMessage .= "Name is required.\\n";
    }
    if (empty($email)) {
        $errorMessage .= "Email is required.\\n";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage .= "Invalid email format.\\n";
    }

    if (!empty($errorMessage)) {
        echo "<script>alert(\"$errorMessage\");</script>";
    } else {
        echo "<script>alert('Form submitted successfully!');</script>";
    }
}
?>

<form method="POST" action="">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name"><br><br>
    <label for="email">Email:</label><br>
    <input type="text" id="email" name="email"><br><br>
    <button type="submit">Submit</button>
</form>

</body>
</html>
